import React from 'react';
import { X, Heart, ExternalLink, Link2, MessageSquareText, Sparkles } from 'lucide-react';
import { CharacterCard } from '../types';

interface DetailModalProps {
  card: CharacterCard | null;
  isOpen: boolean;
  onClose: () => void;
  onCopyLink: (link: string) => void;
  onToggleFavorite: (id: string) => void;
  onOpenChatSimulator?: (card: CharacterCard) => void;
}

export const DetailModal: React.FC<DetailModalProps> = ({
  card,
  isOpen,
  onClose,
  onCopyLink,
  onToggleFavorite,
  onOpenChatSimulator,
}) => {
  const images = (card?.imagesList && card.imagesList.length > 0) ? card.imagesList : card ? [card.imageUrl] : [];
  const [currentImageIndex, setCurrentImageIndex] = React.useState(0);

  React.useEffect(() => {
    if (images.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % images.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [images.length]);

  if (!isOpen || !card) return null;

  const handleCopy = () => {
    const linkToCopy = card.copyLink || card.chatUrl || window.location.href;
    onCopyLink(linkToCopy);
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-[#FFFDF0] w-full max-w-lg rounded-2xl overflow-hidden shadow-2xl border border-[#D4A373]/40 flex flex-col max-h-[90vh]">
        {/* Cover Header */}
        <div className="relative h-64 sm:h-72 w-full overflow-hidden bg-[#FFF9D0]">
          <img
            key={currentImageIndex}
            src={images[currentImageIndex] || card.imageUrl}
            alt={card.name}
            className="w-full h-full object-cover transition-all duration-700 animate-in fade-in"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent" />

          {/* Carousel Indicators if multiple images */}
          {images.length > 1 && (
            <div className="absolute top-4 left-6 z-20 flex items-center gap-1.5 bg-black/40 px-2.5 py-1 rounded-full backdrop-blur-xs">
              {images.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentImageIndex(idx)}
                  className={`h-1.5 rounded-full transition-all cursor-pointer ${
                    idx === currentImageIndex ? 'bg-amber-300 w-4' : 'bg-white/60 hover:bg-white w-1.5'
                  }`}
                  title={`Ảnh ${idx + 1}`}
                />
              ))}
            </div>
          )}

          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-black/40 text-white hover:bg-black/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="absolute bottom-4 left-6 right-6 text-white">
            <span className="inline-block px-3 py-1 text-[10px] font-bold tracking-widest uppercase bg-white/90 text-[#D4A373] border border-[#D4A373]/30 mb-2">
              {card.tag}
            </span>
            <h2 className="font-serif text-3xl font-semibold tracking-normal text-white">{card.name}</h2>
            {card.author && (
              <p className="text-xs text-[#E6C280] font-medium mt-0.5 tracking-wide">
                Tác giả: {card.author}
              </p>
            )}
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-gray-700">
          <div>
            <h4 className="text-[10px] font-bold text-[#D4A373] uppercase tracking-widest mb-1.5 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" /> Mục thẻ / Tags
            </h4>
            <div className="flex flex-wrap gap-1.5 bg-white p-3.5 rounded-xl border border-[#D4A373]/20 shadow-2xs">
              {(card.tagsList || (card.personality ? card.personality.split(',').map(s => s.trim()) : [card.tag])).map((t, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1 text-xs font-bold bg-[#FFF9D0] text-[#B37840] border border-[#D4A373]/30 rounded-full"
                >
                  {t}
                </span>
              ))}
            </div>
          </div>

          {card.description && (
            <div>
              <h4 className="text-[10px] font-bold text-[#D4A373] uppercase tracking-widest mb-1.5 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" /> Mô tả nhân vật
              </h4>
              <p className="text-xs sm:text-sm font-normal leading-relaxed bg-white p-4 rounded-xl border border-[#D4A373]/20 shadow-2xs">
                {card.description}
              </p>
            </div>
          )}

          {card.personality && (
            <div>
              <h4 className="text-[10px] font-bold text-[#D4A373] uppercase tracking-widest mb-1.5">
                Tính cách &amp; Đặc điểm
              </h4>
              <p className="text-xs sm:text-sm font-normal leading-relaxed bg-white p-4 rounded-xl border border-[#D4A373]/20 shadow-2xs">
                {card.personality}
              </p>
            </div>
          )}

          {card.greeting && (
            <div>
              <h4 className="text-[10px] font-bold text-[#D4A373] uppercase tracking-widest mb-1.5">
                Lời chào mẫu
              </h4>
              <p className="text-xs sm:text-sm italic font-serif leading-relaxed bg-[#F9F6E7] p-4 rounded-xl border border-[#D4A373]/30 text-gray-800">
                "{card.greeting}"
              </p>
            </div>
          )}
        </div>

        {/* Action Footer */}
        <div className="p-4 bg-[#FFFDF0] border-t border-[#D4A373]/20 flex items-center justify-end gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="px-3.5 py-2 rounded-full bg-white text-[#D4A373] border border-[#D4A373]/40 hover:bg-amber-50 text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Link2 className="w-3.5 h-3.5" />
              Copy
            </button>

            <a
              href={card.chatUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3.5 py-2 rounded-full bg-[#D4A373] text-white hover:bg-[#b08256] text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Web Chat
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
