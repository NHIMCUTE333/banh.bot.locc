import React, { useState, useEffect } from 'react';
import { MessageSquare, Send, X, Heart, Sparkles, User, Calendar } from 'lucide-react';

export interface FeedbackItem {
  id: string;
  name: string;
  content: string;
  createdAt: string;
}

const STORAGE_KEY = 'banh_bot_loc_feedbacks_v2';

const INITIAL_FEEDBACKS: FeedbackItem[] = [
  {
    id: 'fb-1',
    name: 'Meoiu',
    content: 'Ra char mới nhanh Bột oiii',
    createdAt: '24/07/2026 - 12:45'
  }
];

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FeedbackModal: React.FC<FeedbackModalProps> = ({ isOpen, onClose }) => {
  const [feedbacks, setFeedbacks] = useState<FeedbackItem[]>([]);
  const [name, setName] = useState<string>('');
  const [content, setContent] = useState<string>('');
  const [submittedSuccess, setSubmittedSuccess] = useState<boolean>(false);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        setFeedbacks(JSON.parse(saved));
      } catch (e) {
        setFeedbacks(INITIAL_FEEDBACKS);
      }
    } else {
      setFeedbacks(INITIAL_FEEDBACKS);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_FEEDBACKS));
    }
  }, []);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = now.getFullYear();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const formattedDate = `${day}/${month}/${year} - ${hours}:${minutes}`;

    const newFeedback: FeedbackItem = {
      id: `fb-${Date.now()}`,
      name: name.trim() || 'Bạn ghé thăm ẩn danh',
      content: content.trim(),
      createdAt: formattedDate
    };

    const updated = [newFeedback, ...feedbacks];
    setFeedbacks(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));

    setName('');
    setContent('');
    setSubmittedSuccess(true);
    setTimeout(() => setSubmittedSuccess(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-[9990] flex items-center justify-center sm:justify-end p-3 sm:p-6 transition-opacity duration-300">
      {/* Semi-transparent Backdrop: homepage visible behind */}
      <div 
        onClick={onClose}
        className="absolute inset-0 bg-black/40 backdrop-blur-xs transition-opacity"
      />

      {/* Floating Box Panel occupying ~40% width on desktop with rounded corners, detached from edges */}
      <div className="relative z-10 w-full sm:w-[50%] lg:w-[40%] min-w-[320px] max-w-2xl max-h-[92vh] bg-[#FFFDF0]/95 backdrop-blur-2xl border-2 border-[#D4A373]/50 rounded-3xl shadow-2xl flex flex-col justify-between overflow-hidden my-auto animate-fadeIn">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#D4A373]/30 bg-[#FEFAE0]/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-full bg-[#D4A373] text-white">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif text-lg sm:text-xl font-bold text-[#B37840]">
                Feedback gửi cho Bột
              </h2>
              <p className="text-[11px] text-[#6B8E23] font-semibold">
                Góc nhỏ lắng nghe chia sẻ của bạn
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/80 hover:bg-white text-stone-600 hover:text-stone-900 border border-stone-200 transition-all cursor-pointer"
            title="Đóng"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-6 scrollbar-thin">
          
          {/* Submission Form */}
          <div className="bg-white/90 p-4 rounded-2xl border border-[#D4A373]/30 shadow-xs space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-bold text-[#B37840] uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-[#D4A373]" />
              <span>Gửi lời nhắn mới</span>
            </div>

            {submittedSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold flex items-center gap-2 animate-fadeIn">
                <Heart className="w-4 h-4 text-emerald-600 fill-emerald-600" />
                <span>Cảm ơn lời nhắn siêu đáng yêu của bạn!</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Name của bạn..
                </label>
                <div className="relative">
                  <User className="w-4 h-4 absolute left-3 top-2.5 text-stone-400" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Name của bạn.."
                    className="w-full pl-9 pr-3 py-2 text-xs bg-[#FFFDF0] border border-[#D4A373]/40 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#D4A373]/50 text-stone-800 font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Nội dung mún gửi đến bột??
                </label>
                <textarea
                  rows={3}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Nội dung mún gửi đến bột??"
                  required
                  className="w-full p-3 text-xs bg-[#FFFDF0] border border-[#D4A373]/40 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#D4A373]/50 text-stone-800 font-medium resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 rounded-xl bg-[#D4A373] hover:bg-[#b08256] text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs active:scale-95"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Gửi lời nhắn cho Bột</span>
              </button>
            </form>
          </div>

          {/* Feedback List Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-stone-700 uppercase tracking-wider flex items-center gap-1.5">
                <Heart className="w-4 h-4 text-[#C2185B]" />
                <span>Danh sách feedback ({feedbacks.length})</span>
              </h3>
            </div>

            <div className="space-y-3">
              {feedbacks.map((item) => (
                <div 
                  key={item.id}
                  className="p-3.5 rounded-xl bg-white/80 border border-[#D4A373]/20 shadow-2xs space-y-1.5 hover:bg-white transition-all"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-[#B37840] flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-[#D4A373]" />
                      {item.name}
                    </span>
                    <span className="text-[10px] text-stone-400 font-mono flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {item.createdAt}
                    </span>
                  </div>
                  <p className="text-xs text-stone-700 leading-relaxed font-medium pl-3 border-l-2 border-[#D4A373]/40">
                    {item.content}
                  </p>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#D4A373]/20 bg-[#FEFAE0]/50 text-center text-[11px] text-stone-500 font-medium">
          Cảm ơn bạn đã luôn đồng hành cùng Bột ✨
        </div>

      </div>
    </div>
  );
};
