import React from 'react';
import { Search, X, Home, MessageSquare } from 'lucide-react';
import { CategoryTag } from '../types';

const FacebookIcon = ({ className = "w-3.5 h-3.5" }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
  </svg>
);

const InstagramIcon = ({ className = "w-3.5 h-3.5" }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
  </svg>
);

interface SearchBarProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  selectedTag: CategoryTag;
  setSelectedTag: (tag: CategoryTag) => void;
  showFavoritesOnly: boolean;
  setShowFavoritesOnly: (val: boolean) => void;
  onGoWelcome?: () => void;
  onOpenFeedback?: () => void;
  totalCards: number;
  favoriteCount: number;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  searchTerm,
  setSearchTerm,
  selectedTag,
  setSelectedTag,
  showFavoritesOnly,
  setShowFavoritesOnly,
  onGoWelcome,
  onOpenFeedback,
  totalCards,
  favoriteCount
}) => {
  const tags: { label: CategoryTag; dotColor: string }[] = [
    { label: 'Tất cả', dotColor: 'bg-[#D4A373]' },
    { label: 'Cổ trang', dotColor: 'bg-[#C2185B]' },
    { label: 'Hiện đại', dotColor: 'bg-[#A3B18A]' },
  ];

  return (
    <div className="space-y-4 mb-6 bg-white/92 backdrop-blur-md p-5 rounded-3xl border border-[#D4A373]/40 shadow-xl">
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3.5 border-b border-[#D4A373]/25 gap-3">
        <div className="flex items-center gap-3">
          {onGoWelcome && (
            <button
              onClick={onGoWelcome}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider bg-white border border-[#D4A373]/50 text-[#D4A373] hover:bg-[#D4A373] hover:text-white transition-all shadow-xs cursor-pointer active:scale-95"
              title="Quay lại trang đầu"
            >
              <Home className="w-3.5 h-3.5" />
              <span>Quay lại</span>
            </button>
          )}

          <div className="flex flex-col">
            <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
              <span className="font-serif text-2xl sm:text-3xl font-bold text-[#B37840] tracking-tight leading-none">
                Weo com đến với Bột
              </span>
              <div className="flex items-center gap-1.5 flex-wrap">
                <a
                  href="https://www.facebook.com/profile.php?id=61590688029529"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-transparent text-[#1877F2] hover:bg-[#1877F2] hover:text-white border border-[#1877F2]/40 transition-all hover:scale-105 active:scale-95 cursor-pointer shadow-xs"
                  title="Ghé thăm Fanpage của Bột"
                >
                  <FacebookIcon className="w-3.5 h-3.5" />
                  <span>Fanpage</span>
                </a>
                <a
                  href="https://www.facebook.com/song.an.113815"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-transparent text-[#1877F2] hover:bg-[#1877F2] hover:text-white border border-[#1877F2]/40 transition-all hover:scale-105 active:scale-95 cursor-pointer shadow-xs"
                  title="Facebook cá nhân"
                >
                  <FacebookIcon className="w-3.5 h-3.5" />
                  <span>Fb cá nhân</span>
                </a>
                <a
                  href="https://www.instagram.com/hate.chocolatee/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-transparent text-[#E1306C] hover:bg-[#E1306C] hover:text-white border border-[#E1306C]/40 transition-all hover:scale-105 active:scale-95 cursor-pointer shadow-xs"
                  title="Instagram"
                >
                  <InstagramIcon className="w-3.5 h-3.5" />
                  <span>Insta</span>
                </a>
                {onOpenFeedback && (
                  <button
                    onClick={onOpenFeedback}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-bold bg-[#D4A373] hover:bg-[#b08256] text-white border border-[#D4A373]/80 transition-all hover:scale-105 active:scale-95 cursor-pointer shadow-md ring-2 ring-[#D4A373]/20"
                    title="Gửi Feedback cho Bột"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Feedback</span>
                  </button>
                )}
              </div>
            </div>
            <span className="text-xs sm:text-sm font-semibold text-[#6B8E23] mt-1.5">
              Các yêu chơi vui.
            </span>
          </div>
        </div>
      </div>

      {/* Input Search */}
      <div className="relative">
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Tìm nhân vật, chồng của em..."
          className="w-full py-3 pl-11 pr-10 border border-[#D4A373]/40 rounded-full text-sm outline-none bg-white/95 focus:ring-2 focus:ring-[#D4A373]/50 focus:border-[#D4A373] transition-all shadow-inner text-gray-800 placeholder-[#8B7355]/60"
        />
        <Search className="w-4 h-4 text-[#D4A373] absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
        {searchTerm && (
          <button
            onClick={() => setSearchTerm('')}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Category Tag Filters (Lướt mượt mà, tự do) */}
      <div className="relative group/tags">
        <div className="flex items-center gap-2.5 overflow-x-auto no-scrollbar scroll-smooth touch-pan-x py-2 px-1 w-full justify-start sm:justify-center whitespace-nowrap active:cursor-grabbing select-none">
          {tags.map((item) => {
            const isSelected = selectedTag === item.label && !showFavoritesOnly;
            return (
              <button
                key={item.label}
                onClick={() => {
                  setShowFavoritesOnly(false);
                  setSelectedTag(item.label);
                }}
                className={`shrink-0 flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold tracking-wide transition-all cursor-pointer border shadow-2xs ${
                  isSelected
                    ? 'border-[#D4A373] bg-[#D4A373] text-white font-extrabold shadow-sm scale-105 ring-2 ring-[#D4A373]/30'
                    : 'border-[#D4A373]/30 bg-white/95 text-gray-700 hover:border-[#D4A373] hover:bg-white hover:text-[#B37840]'
                }`}
              >
                <div className={`w-2.5 h-2.5 rounded-full shrink-0 ${isSelected ? 'bg-white' : item.dotColor}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
